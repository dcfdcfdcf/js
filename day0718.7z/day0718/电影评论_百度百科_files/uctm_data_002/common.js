try{document.execCommand("BackgroundImageCache",!1,!0)}catch(err){}
