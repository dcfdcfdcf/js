// JavaScript Document

function getStyle( obj,attr )
{

	/*if( obj.currentStyle )
	{
		return  obj.currentStyle[attr];
	}
	else
	{
		return getComputedStyle(obj)[attr] ;
	};*/
	
	return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr];
	
};

function css( obj,attr,value )
{
	if( arguments.length == 2 )
	{
		
		return obj.style[attr];
	}
	else if( arguments.length == 3 )
	{
		//console.log(333);
		obj.style[attr] = value;
	};
	
};

function toZero( n )
{
	return n < 10 ? '0'+n : ''+n;
};

function getId( s )
{
	return document.getElementById( s );
};

function v( s )
{
	if( typeof s == 'function' )
	{
		window.onload = s;
	}
	else if( typeof s == 'string' ){
		return document.getElementById( s );		
	}
	else if( typeof s == 'object' )
	{
		return s;
	};
};

function move( obj,attr,target,endFn )
{
	
	clearInterval( timer );
	timer = setInterval( function(){
		var dir = parseInt(getStyle( obj,attr )) < target ? 10 : -10;//判断方向
		var speed = parseInt(getStyle( obj,attr )) + dir;
		
		if( speed >= target && dir > 0 || speed <= target && dir < 0 )//500
		{
			speed = target;
			clearInterval( timer );
			endFn && endFn();
			
		};
		
		obj.style[attr] = speed + 'px';
		
		
	},30 );
	
};
