// JavaScript Document
window.onload = function()
	{
			var oH2 = document.getElementById("oh2");
	var oUl2 = document.getElementById("ul2");
	var oUl1 = document.getElementById("ul1");
	oUl1.onmouseover=function()
	{
		oUl2.style.display="block";
		oH2.style.background="yellow";	
		oH2.style.color="white";
	}
	oUl1.onmouseout=function()
	{
		oUl2.style.display="none";
		oH2.style.background="blue";	
		oH2.style.color="white";

	}	
	
	
	};