// JavaScript Document
//这里只能写js语言

//window.onload = function()

//  {} 大括号 就是存放很多很多代码 ： 存放大量的代码块

{
	var oUl1 = document.getElementById('ul1');
	var oH2 = document.getElementById('oH2');
	var oUl2 = document.getElementById('ul2')
	
	oUl1.onmouseover = function()
	{
		oH2.style.fontSize = '30px';
		oH2.style.color = 'blue';
		oH2.style.background = 'red';
		oUl2.style.display = 'block';
		
	};
	
	oUl1.onmouseout = function()
	{
		oH2.style.color = 'white';
		oH2.style.background = 'blue';
		oUl2.style.display = 'none';
	};
};
