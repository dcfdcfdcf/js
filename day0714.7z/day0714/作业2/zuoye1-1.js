// JavaScript Document
window.onload = function()
{
	var oBox1 = document.getElementById('box1');
	var oUl = oBox1.getElementsByTagName('ul')[0];
	var aLi = oUl.getElementsByTagName('li');
	var aDl = oBox1.getElementsByTagName('dl');
	var num = [4,8,12,16];
	var Let = ['a','b','c','d'];
	var len = aLi.length;
	for(var i=0;i < len;i++)
	{
		aPlus(aDl[i],num[i],Let[i],i);	//追加a标签
		aLi[i].index = i;
		aLi[i].onmouseover =function()
		{
			for(var i = 0;i < len; i++)
			{
				aLi[i].className = '';	
				aDl[i].style.display = 'none';
			};
			this.className = 'hover';
			aDl[this.index].style.display = 'block';	
		};
		
		NumSwitch(aDl[i]);	
	};
	
	function NumSwitch(aDl)
	{
		var oDd = aDl.getElementsByTagName('dd')[0];
		var oDt = aDl.getElementsByTagName('dt')[0];
		var aNum = oDd.getElementsByTagName('a');
		var len = aNum.length;
		for(var i = 0;i < len; i ++)
		{
			aNum[i].onmouseover = function()
			{
				for(var i = 0; i < len; i ++)
				{
					aNum[i].className = '';	
				};
				
				this.className = 'hover';
				oDt.innerHTML  = this.innerHTML;
			};	
		};
	};
	function aPlus(aDl,num,Let,i)
	{
		var str = '';
		var odd = aDl.getElementsByTagName('dd')[0];
		for(var j = 0; j < num ;j++)
		{
			str += '<a>'+Let+''+(j+1)+'</a>';
		};
		odd.innerHTML = str;
	};
		
};