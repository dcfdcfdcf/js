// JavaScript Document
window.onload = function()
{
	var oDiv = document.getElementById('div1');
	var oUl = oDiv.getElementsByTagName('ul')[0];
	var aIpt = oUl.getElementsByTagName('input');
	var aLi = oUl.getElementsByTagName('li');
	var aLabel = oUl.getElementsByTagName('label');
	var oAll = oDiv.getElementsByTagName('p')[0].getElementsByTagName('input')[0];
	var num = 5;
	var str = '';
	var col = '';
	var bgColor = ['#ff0000','#008000']
	for(var i = 0;i < num; i ++)
	{
		str += '<li style="background:'+bgColor[i%bgColor.length]+'">';
		str += '<label><input type="checkbox"></label></li>';
	};
	oUl.innerHTML = str;
	var len = aLi.length;
	var flag = 0;
	for(var i = 0; i < len ; i ++)
	{
		aLi[i].index = i;
		aLi[i].onmouseover = function()
		{
			this.style.background = "#ffff00";
		};
		aLi[i].onmouseout = function()
		{
			if(!aIpt[this.index].checked)
			{
				this.style.background = bgColor[this.index%bgColor.length];
			};
		};
		aIpt[i].onclick = function()
		{
			this.checked? flag++ :flag--;
			flag == len? oAll.checked = true: oAll.checked = false;
			console.log(flag) 	
		};
		
	};
	oAll.onclick = function()
	{
		if(this.checked)
		{
			for(var i = 0; i < len; i ++)	
			{
				aIpt[i].checked = true;	
				aLi[i].background = '#ffff00' ;	
			};
			flag = len;
		}
		else
		{
			for(var i = 0; i < len; i ++)	
			{
				aIpt[i].checked = false;
				aLi[i].background = bgColor[i%bgColor.length] ;	
			};
			flag = 0;
		};	
	};


};