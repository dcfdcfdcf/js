// JavaScript Document
window.onload = function()
{
	var oDiv = document.getElementById('div1');
	var oUl = oDiv.getElementsByTagName('ul')[0];
	var aIpt = oUl.getElementsByTagName('input');
	var aLi = oUl.getElementsByTagName('li');
	var aLabel = oUl.getElementsByTagName('label');
	var oAll = oDiv.getElementsByTagName('p')[0].getElementsByTagName('input')[0];
	var num = 5;
	var str = '';
	var col = '';
	var bgColor = ['#ff0000','#008000']
	for(var i = 0;i < num; i ++)
	{
		str += '<li style="background:'+bgColor[i%bgColor.length]+'">';
		str += '<label><input type="checkbox"></label></li>';
	};
	oUl.innerHTML = str;
	for(var i = 0; i< num; i++)
	{
		aIpt[i].index = i;
		aIpt[i].onclick = function ()
		{
			if(this.checked)
			{
				aLi[this.index].style.background = '#ffff00';	
			}
			else
			{
				aLi[this.index].style.background = 	bgColor[this.index%bgColor.length];
			};
			if(aIpt[1].checked && aIpt[2].checked &&aIpt[3].checked &&aIpt[4].checked &&aIpt[0].checked )
			{
				oAll.checked = true;	
			}
			else
			{
				oAll.checked = false;	
			};
		};
		aLi[i].onmouseover = function()
		{
			this.style.background = "#ffff00";			
		}
		aLi[i].index = i;
		aLi[i].onmouseout = function()
		{
			console.log(aIpt[this.index].checked )
			if(aIpt[this.index].checked )
			{
				this.style.background = "#ffff00";		
			}
			else
			{
				this.style.background = bgColor[this.index%bgColor.length];	
			}
		};
	};
	oAll.onclick = function()
	{
		for(var i = 0;i < num; i ++)
		{
			if(oAll.checked)
			{
				aIpt[i].oldChecked = aIpt[i].checked//将原来的状态保存
				aLi[i].oldbg1 = aLi[i].style.background;//
				//console.log(aLi[i].oldbg1);
				aIpt[i].checked = true;
				aLi[i].style.background = '#ffff00';
			}
			else
			{
				aIpt[i].checked = aIpt[i].oldChecked;
				aLi[i].style.background = aLi[i].oldbg1;	
			};
		};
	};
};