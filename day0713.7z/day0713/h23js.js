// JavaScript Document
window.onload = function()
{
	var	oDiv = document.getElementById('div');
	var oSum = oDiv.getElementsByTagName('p')[0];
	var obg = oDiv.getElementsByTagName('p')[1];
	//var obgNum = oDiv.getElementsByTagName('p')[1].getElementsByTagName('b')[0];
	var oUl = oDiv.getElementsByTagName('ul')[0];
	var aLi = oDiv.getElementsByTagName('li');
	var aNum = oUl.getElementsByTagName('i');
	var aPrice = oUl.getElementsByTagName('span');
	var num1 = [0,0,0,0];
	var str = '';
	for( var i = 0;i < aLi.length;i++)
	{
		fn(i);
	};
	
	function fn(i)
	{
		var oLi = oDiv.getElementsByTagName('li')[i];
		var oMinus = oLi.getElementsByTagName('input')[0];
		var oPluse = oLi.getElementsByTagName('input')[1];
		var oNum = oLi.getElementsByTagName('i')[0];
		var oPrice = oLi.getElementsByTagName('span')[0];
		var oTotal = oLi.getElementsByTagName('b')[0];
		var num = 0;
		var str = '';
		
		oPluse.onclick = function()
		{
			num++;
			oNum.innerHTML = num;
			str = num*parseFloat(oPrice.innerHTML) ;
			oTotal.innerHTML = str;
			num1[i] = Number(oTotal.innerHTML);
			searchbg();
		};
		oMinus.onclick = function()
		{
			num--;
			if(num < 0)
			{
				num = 0;
			};
			oNum.innerHTML = num;	
			str = num*parseFloat(oPrice.innerHTML) ;
			oTotal.innerHTML = str;
			num1[i] = Number(oTotal.innerHTML);
			searchbg();

		};
	};
	
	function searchbg()
	{
		var numbgindex = 0;
		var numbg = 0;
		var SumNum = 0;
		for(var j = 0;j < num1.length;j++)
		{
			SumNum += num1[j]
			if(numbg < num1[j])
			{
				numbg = num1[j]	;
				numbgindex = j;
			};
		};
		oSum.innerHTML = '商品总价为：'+SumNum+'元' ;
		obg.innerHTML = '最贵的商品单价为：'+parseFloat( aPrice[numbgindex].innerHTML)+'元,&nbsp;共'+aNum[numbgindex].innerHTML +'件';
		//obgNum.innerHTML = aNum[numbgindex].innerHTML;
	};
};