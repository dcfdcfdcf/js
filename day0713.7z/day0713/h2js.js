// JavaScript Document
window.onload = function()
{
	
	
	var	oDiv = document.getElementById('div');
	var oSum = oDiv.getElementsByTagName('p')[0].getElementsByTagName('i')[0];
	var obg = oDiv.getElementsByTagName('p')[1].getElementsByTagName('i')[0];
	var obgNum = oDiv.getElementsByTagName('p')[1].getElementsByTagName('b')[0];
	var oLi = oDiv.getElementsByTagName('li');
	var num1 = [0,0,0,0];
	var num2 = 0;
	var numbg = num1[0];
	var numbgindex = 0;
	
	var str = '';
	for( var i = 0;i < oLi.length;i++)
	{
		fn(i);
		//num2 += num1[i]
		//oSum.innerHTML = num2;
	};
	

	
	oSum.innerHTML = num2;


	
	function fn(i)
	{
		var oLi = oDiv.getElementsByTagName('li')[i];
		var oMinus = oLi.getElementsByTagName('input')[0];
		var oPluse = oLi.getElementsByTagName('input')[1];
		var oNum = oLi.getElementsByTagName('i')[0];
		var oPrice = oLi.getElementsByTagName('span')[0];
		var oTotal = oLi.getElementsByTagName('b')[0];
		
		
		var num = 0;
		var str = '';
		
		oPluse.onclick = function()
		{
			num++;
			oNum.innerHTML = num;
			str = num*parseFloat(oPrice.innerHTML) ;
			oTotal.innerHTML = str;
			num1[i] = Number(oTotal.innerHTML);
			//oSum.innerHTML = parseFloat(str) + '元'
			//oSum.innerHTML = (parseFloat(oSum.innerHTML) + parseFloat(str)) + '元'
			num2 = num1[0]+num1[1]+num1[2]+num1[3];
			oSum.innerHTML = num2;
			for(var j = 0;j < num1.length;j++)
			{
				if(numbg < num1[j])
				{
					numbg = num1[j]	;
					numbgindex = j;
				}
/*				else
				{
					numbg = numbg;
					numbgindex = numbgindex ;	
				};
*/				
			};
			if(numbgindex == i)
			{
				obg.innerHTML = oPrice.innerHTML;
				obgNum.innerHTML = oNum.innerHTML;
			}
			 
			
		};
		oMinus.onclick = function()
		{
			num--;
			if(num < 0)
			{
				num = 0;
			};
			oNum.innerHTML = num;	
			str = num*parseFloat(oPrice.innerHTML) ;
			oTotal.innerHTML = str;
			num1[i] = Number(oTotal.innerHTML);

			num2 = num1[0]+num1[1]+num1[2]+num1[3];
			oSum.innerHTML = num2;
			for(var j = 0;j < num1.length;j++)
			{
				if(numbg < num1[j])
				{
					numbg = num1[j]	;
					numbgindex = j;
				}
/*				else
				{
					numbg = numbg;
					numbgindex = numbgindex;	
				};
*/			};
			
			if(numbgindex == i)
			{
				obg.innerHTML = oPrice.innerHTML;
				obgNum.innerHTML = oNum.innerHTML;
			}

		};
		

		
	};
};