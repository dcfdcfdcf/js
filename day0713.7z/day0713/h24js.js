// JavaScript Document
window.onload = function()
{
	var	oDiv = document.getElementById('div');
	var oSum = oDiv.getElementsByTagName('p')[0];
	var obg = oDiv.getElementsByTagName('p')[1];
	var oUl = oDiv.getElementsByTagName('ul')[0];
	var aLi = oDiv.getElementsByTagName('li');
	var aTotal = oUl.getElementsByTagName('b');
	var aNum = oUl.getElementsByTagName('i');
	var aPrice = oUl.getElementsByTagName('span');
	var num1 = [0,0,0,0];
	var str = '';
	var len = aLi.length;
	for( var i = 0;i < len;i++)
	{
		fn(aLi[i]);
	};
	
	function fn(oLi)
	{
		var oMinus = oLi.getElementsByTagName('input')[0];
		var oPluse = oLi.getElementsByTagName('input')[1];
		var oNum = oLi.getElementsByTagName('i')[0];
		var oPrice = oLi.getElementsByTagName('span')[0];
		var oTotal = oLi.getElementsByTagName('b')[0];
		var str = '';
		
		oPluse.onclick = function()
		{
			oNum.innerHTML = (parseInt(oNum.innerHTML) + 1);
			oTotal.innerHTML = parseInt(oNum.innerHTML)* parseFloat(oPrice.innerHTML) + '元'
			sum();
		};
		oMinus.onclick = function()
		{
			if(parseInt(oNum.innerHTML) == 0)
			{
				oNum.innerHTML = parseInt(oNum.innerHTML) ;
			}
			else
			{
				oNum.innerHTML = (parseInt(oNum.innerHTML)-1) ; 
			};
			oTotal.innertHTML = parseInt(oNum.innerHTML)* parseFloat(oPrice.innerHTML) + '元'
			sum();
		};
	};
	
	function sum ()
	{
		var SumNum = 0;
		var NumNum = 0;
		var maxPrice = 0;
		for(var i = 0; i < len;i++ )
		{
			SumNum += parseFloat(aTotal[i].innerHTML);
			NumNum += parseFloat(aNum[i].innerHTML);
			if(parseFloat(aNum[i].innerHTML) > 0)
			{
				if( maxPrice < parseFloat(aPrice[i].innerHTML))
				{
					maxPrice = 	parseFloat(aPrice[i].innerHTML);
				};
			};
		};
		oSum.innerHTML = '商品总价为：'+SumNum + '元';
		obg.innerHTML = '最贵的商品单价为：'+ maxPrice +'元, 共'+ NumNum+'件';
	};
};