// JavaScript Document

function getStyle( obj,attr )
{

	/*if( obj.currentStyle )
	{
		return  obj.currentStyle[attr];
	}
	else
	{
		return getComputedStyle(obj)[attr] ;
	};*/
	
	return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr];
	
};
