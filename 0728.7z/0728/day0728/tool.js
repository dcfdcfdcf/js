// JavaScript Document

function getStyle( obj,attr )
{

	/*if( obj.currentStyle )
	{
		return  obj.currentStyle[attr];
	}
	else
	{
		return getComputedStyle(obj)[attr] ;
	};*/
	
	return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr];
	
};

function css( obj,attr,value )
{
	if( arguments.length == 2 )
	{
		
		return obj.style[attr];
	}
	else if( arguments.length == 3 )
	{
		//console.log(333);
		obj.style[attr] = value;
	};
	
};

function toZero( n )
{
	return n < 10 ? '0'+n : ''+n;
};

function getId( s )
{
	return document.getElementById( s );
};

function v( s )
{
	if( typeof s == 'function' )
	{
		window.onload = s;
	}
	else if( typeof s == 'string' ){
		return document.getElementById( s );		
	}
	else if( typeof s == 'object' )
	{
		return s;
	};
};

//var timer = null;
//匀速运动框架
function move( obj,attr,target,endFn )
{
	
	clearInterval( obj.timer );//clearInterval 脾气特别好。可以清除任意数据类型
	obj.timer = setInterval( function(){
		var dir = parseInt(getStyle( obj,attr )) < target ? 10 : -10;//判断方向
		var speed = parseInt(getStyle( obj,attr )) + dir;
		
		if( speed >= target && dir > 0 || speed <= target && dir < 0 )//500
		{
			speed = target;
			clearInterval( obj.timer );
			endFn && endFn();
			
		};
		
		obj.style[attr] = speed + 'px';
		
		
	},30 );
	
};

//检测是否为一个数字
function isNum( s )
{
	var num = 0;
	for( var i=0;i<s.length;i++ )
	{
		num++;
		if( !( s.charCodeAt(i) >= 48 && s.charCodeAt(i) <= 57 ) )
		{
			console.log(num);
			return false;
		};
	};
	
	return true;
	
};

//元素位置
function getPosition( obj )
{
	var position = { "L":0,"T":0 };

	//var obj = oDiv2;
	
	while( obj )
	{
		position.L += obj.offsetLeft;
		position.T += obj.offsetTop;
		
		obj = obj.offsetParent;
	};
	
	return position;
};


//通过className找元素
function byClassName( oParent,sClassName )
{
	
	var arrEle = [];
	
	var aEle = oParent.getElementsByTagName('*');
	
	//console.log( aEle );
	
	for(var i=0;i<aEle.length;i++)
	{
		
		var arrClassName = aEle[i].className.split(' ');
		
		//console.log( arrClassName );
		
		for(var j=0;j<arrClassName.length;j++)
		{
			if( arrClassName[j] == sClassName )
			{
				arrEle.push( aEle[i] );
				break;
			};
		};
		
	};
	
	return arrEle;
	
};


//缓冲运动 
function sMove(obj,json,endFn)
{
	clearInterval( obj.timer );
	
	obj.timer = setInterval(function(){
		
		//for in循环如果里面不加清定时器的功能，那么所有的属性都可以到达目标位置。
		/*
			
			理解为：for in循环里面就是 为了让元素到达目标位置的； 每次执行for in循环 就是让当前位置的cur + speed 累加的。
			
			判断所有的属性到达到目标位置与否。如果所有属性都到达目标位置，则清除定时器
			
		*/
		
		var isStop = true;//假如都到达目标位置了，则为true，只要有一个属性未到达目标位置，则为false
		
		for( var attr in json )
		{
			if( attr == 'opacity' )
			{
				var cur = Math.round(parseFloat(getStyle( obj,attr ))*100);//
			}
			else
			{
				var cur = parseInt( getStyle( obj,attr ) );//
			};
			
			
			var speed = (json[attr] - cur)/10;
			speed = speed > 0 ? Math.ceil( speed ) : Math.floor( speed );

			cur += speed;
			
			if( cur != json[attr] )
			{
				isStop = false;
			};
			
			if( attr == 'opacity' )
			{
				obj.style.opacity = cur/100;
				obj.style.filter = 'alpha(opacity='+ cur +')';
			}
			else
			{
				obj.style[attr] = cur + 'px';
			};
		};
		
		
		if( isStop )
		{ 
			clearInterval( obj.timer );
			endFn && endFn();
		};
	
		
	},30);
	
};
