// JavaScript Document

function getStyle( obj,attr )
{

	/*if( obj.currentStyle )
	{
		return  obj.currentStyle[attr];
	}
	else
	{
		return getComputedStyle(obj)[attr] ;
	};*/
	
	return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr];
	
};

function css( obj,attr,value )
{
	if( arguments.length == 2 )
	{
		
		return obj.style[attr];
	}
	else if( arguments.length == 3 )
	{
		//console.log(333);
		obj.style[attr] = value;
	};
	
};

function toZero( n )
{
	return n < 10 ? '0'+n : ''+n;
};

function getId( s )
{
	return document.getElementById( s );
};

function v( s )
{
	if( typeof s == 'function' )
	{
		window.onload = s;
	}
	else if( typeof s == 'string' ){
		return document.getElementById( s );		
	}
	else if( typeof s == 'object' )
	{
		return s;
	};
};

//var timer = null;
//匀速运动框架
function move( obj,attr,target,endFn )
{
	
	clearInterval( obj.timer );//clearInterval 脾气特别好。可以清除任意数据类型
	obj.timer = setInterval( function(){
		var dir = parseInt(getStyle( obj,attr )) < target ? 10 : -10;//判断方向
		var speed = parseInt(getStyle( obj,attr )) + dir;
		
		if( speed >= target && dir > 0 || speed <= target && dir < 0 )//500
		{
			speed = target;
			clearInterval( obj.timer );
			endFn && endFn();
			
		};
		
		obj.style[attr] = speed + 'px';
		
		
	},30 );
	
};
//缓冲运动
function move1( obj,attr,target,endFn )
{
	
	clearInterval( obj.timer );//clearInterval 脾气特别好。可以清除任意数据类型
	obj.timer = setInterval( function(){
		var dir = parseInt(getStyle( obj,attr )) < target ? 10 : -10;//判断方向
		var speed = parseInt(getStyle( obj,attr )) + dir;
		
		if( speed >= target && dir > 0 || speed <= target && dir < 0 )//500
		{
			speed = target;
			clearInterval( obj.timer );
			endFn && endFn();
			
		};
		
		obj.style[attr] = speed + 'px';
		
		
	},30 );
	
};
//检测是否为一个数字
function isNum( s )
{
	var num = 0;
	for( var i=0;i<s.length;i++ )
	{
		num++;
		if( !( s.charCodeAt(i) >= 48 && s.charCodeAt(i) <= 57 ) )
		{
			console.log(num);
			return false;
		};
	};
	
	return true;
	
};

//元素位置
function getPosition( obj )
{
	var position = { "L":0,"T":0 };

	//var obj = oDiv2;
	
	while( obj )
	{
		position.L += obj.offsetLeft;
		position.T += obj.offsetTop;
		
		obj = obj.offsetParent;
	};
	
	return position;
};


//通过className找元素
function byClassName( oParent,sClassName )
{
	
	var arrEle = [];
	
	var aEle = oParent.getElementsByTagName('*');
	
	//console.log( aEle );
	
	for(var i=0;i<aEle.length;i++)
	{
		
		var arrClassName = aEle[i].className.split(' ');
		
		//console.log( arrClassName );
		
		for(var j=0;j<arrClassName.length;j++)
		{
			if( arrClassName[j] == sClassName )
			{
				arrEle.push( aEle[i] );
				break;
			};
		};
		
	};
	
	return arrEle;
	
};
